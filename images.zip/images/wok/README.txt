Lege hier Bilder für die Kategorie 'Wok' ab. Unterstützt: jpg, jpeg, png, webp.
