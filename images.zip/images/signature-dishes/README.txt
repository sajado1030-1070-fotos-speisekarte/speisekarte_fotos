Lege hier Bilder für die Kategorie 'Signature Dishes' ab. Unterstützt: jpg, jpeg, png, webp.
