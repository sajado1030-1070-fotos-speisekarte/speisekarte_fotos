Lege hier Bilder für die Kategorie 'Thai Rotcurry/Thai Redcurry' ab. Unterstützt: jpg, jpeg, png, webp.
